from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, sqlite3, urllib.parse, os, re
ROOT=Path(__file__).resolve().parent
DB=ROOT/'case.db'

def create_db():
    if DB.exists(): DB.unlink()
    con=sqlite3.connect(DB)
    con.executescript('''
    CREATE TABLE incident_report(id INTEGER PRIMARY KEY, incident_date TEXT, location TEXT, incident_type TEXT, description TEXT);
    CREATE TABLE person(id INTEGER PRIMARY KEY, name TEXT, class_name TEXT, role TEXT);
    CREATE TABLE interview(person_id INTEGER, testimony TEXT);
    CREATE TABLE club_member(member_code TEXT PRIMARY KEY, person_id INTEGER, club_name TEXT, status TEXT);
    CREATE TABLE access_log(id INTEGER PRIMARY KEY, member_code TEXT, entry_time TEXT, exit_time TEXT, door TEXT);
    CREATE TABLE vehicle(person_id INTEGER, plate_number TEXT, vehicle_type TEXT, color TEXT);
    CREATE TABLE message_log(id INTEGER PRIMARY KEY, sender_id INTEGER, receiver_id INTEGER, sent_time TEXT, message TEXT);
    INSERT INTO incident_report VALUES
    (1,'2026-10-14','본관 1층 전시실','트로피 분실','오후 5시 30분에서 6시 사이 우승 트로피가 사라졌다. 목격자는 최민지(3학년 1반)와 이준호(3학년 2반)다. 두 학생의 진술을 확인하라.'),
    (2,'2026-10-10','체육관','분실물','농구공 하나를 분실했으나 다음 날 회수했다.'),
    (3,'2026-10-12','컴퓨터실','기기 점검','모니터 전원 케이블을 교체했다.');
    INSERT INTO person VALUES
    (101,'최민지','3학년 1반','목격자'),(102,'이준호','3학년 2반','목격자'),
    (103,'박도윤','3학년 1반','학생'),(104,'김하늘','3학년 1반','학생'),
    (105,'정우진','3학년 2반','학생'),(106,'서지안','3학년 2반','학생'),
    (107,'오준혁','3학년 3반','학생'),(108,'한유나','3학년 3반','학생'),
    (109,'문서준','3학년 1반','학생'),(110,'강지후','3학년 2반','학생'),
    (111,'최서연','3학년 3반','학생'),(112,'고민재','3학년 3반','학생'),
    (113,'이수현','3학년 1반','학생'),(114,'백현우','3학년 2반','학생'),
    (115,'임채린','3학년 3반','학생'),(116,'윤서진','3학년 1반','학생');
    INSERT INTO interview VALUES
    (101,'후드티를 입은 학생이 전시실 쪽에서 나왔어요. 가방에 로봇동아리 회원증이 달려 있었는데, 회원번호가 R7로 시작했어요.'),
    (102,'그 학생은 오후 5시 40분 무렵 전시실로 들어갔어요. 주차장에 세워 둔 이동 수단의 번호 끝자리가 314였던 것 같아요.'),
    (104,'저는 그 시간에 운동장에 있었어요.'),
    (103,'트로피를 가져간 것은 맞습니다. 하지만 누군가 메시지로 전시실에 있는 트로피를 옮기라고 부탁했습니다. 메시지 기록을 확인해 보세요.'),
    (111,'전시실 정리와 관련된 연락을 한 적이 있습니다.');
    INSERT INTO club_member VALUES
    ('R701',103,'로봇동아리','활동'),('R702',104,'로봇동아리','활동'),('R703',105,'로봇동아리','활동'),
    ('R704',107,'로봇동아리','활동'),('R705',109,'로봇동아리','활동'),('R706',112,'로봇동아리','휴면'),
    ('D201',106,'디자인동아리','활동'),('D202',108,'디자인동아리','활동'),
    ('R707',114,'로봇동아리','활동'),('M101',111,'미디어동아리','활동');
    INSERT INTO access_log(member_code,entry_time,exit_time,door) VALUES
    ('R701','2026-10-14 17:41','2026-10-14 17:57','전시실'),
    ('R702','2026-10-14 16:15','2026-10-14 16:35','전시실'),
    ('R703','2026-10-14 17:44','2026-10-14 17:51','실습실'),
    ('R704','2026-10-14 17:35','2026-10-14 17:49','전시실'),
    ('R705','2026-10-14 18:10','2026-10-14 18:21','전시실'),
    ('R707','2026-10-14 17:38','2026-10-14 17:45','전시실'),
    ('D201','2026-10-14 17:47','2026-10-14 18:05','디자인실');
    INSERT INTO vehicle VALUES
    (103,'경기 12가 8314','전동킥보드','검정'),
    (104,'경기 31나 7152','자전거','파랑'),
    (105,'경기 41다 2314','자전거','흰색'),
    (107,'경기 27라 9581','전동킥보드','회색'),
    (109,'경기 51마 8042','자전거','검정'),
    (114,'경기 21바 6019','전동킥보드','흰색'),
    (111,'경기 11사 5527','자전거','노랑');
    INSERT INTO message_log(sender_id,receiver_id,sent_time,message) VALUES
    (111,103,'2026-10-14 17:25','전시실 트로피를 잠시 창고에 옮겨 줘. 담당 선생님께는 내가 말씀드릴게.'),
    (104,103,'2026-10-14 13:10','오늘 동아리 회의는 4시에 시작해.'),
    (105,107,'2026-10-14 16:25','내일 실습 준비물 잊지 마.'),
    (111,108,'2026-10-14 11:02','행사 포스터 수정해 줘.');
    ''')
    con.commit();con.close()

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
    def do_POST(self):
        if self.path != '/api/query' and self.path != '/api/answer': return self.send_error(404)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>20000: raise ValueError('요청이 너무 깁니다.')
            data=json.loads(self.rfile.read(length) or '{}')
            if self.path=='/api/answer':
                ans=str(data.get('name','')).replace(' ','').strip()
                level=int(data.get('level',1))
                expected='박도윤' if level==1 else '최서연'
                result={'correct':ans==expected,'message':('정답입니다! '+('트로피를 가져간 학생을 찾았습니다. 이제 배후 인물을 추리해 보세요.' if level==1 else '축하합니다! 사건을 완전히 해결했습니다.')) if ans==expected else '다시 단서를 검토해 보세요. 표를 연결하면 답을 찾을 수 있습니다.'}
            else:
                sql=str(data.get('sql','')).strip()
                if not sql:raise ValueError('SQL 문장을 입력하세요.')
                # Only a single read-only SELECT statement or WITH statement allowed.
                if not re.match(r'^\s*(SELECT|WITH|PRAGMA\s+table_info\s*\()',sql,re.I):raise ValueError('조회(SELECT)만 허용됩니다.')
                con=sqlite3.connect(f'file:{DB}?mode=ro',uri=True)
                con.row_factory=sqlite3.Row
                con.execute('PRAGMA query_only=ON')
                con.set_progress_handler(lambda: 1,100000)
                try:
                    cur=con.execute(sql)
                    cols=[d[0] for d in cur.description] if cur.description else []
                    rows=[list(r) for r in cur.fetchmany(101)]
                    result={'columns':cols,'rows':rows[:100],'truncated':len(rows)>100}
                finally:con.close()
        except Exception as e: result={'error':str(e)}
        encoded=json.dumps(result,ensure_ascii=False).encode('utf-8')
        self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(encoded)));self.end_headers();self.wfile.write(encoded)
    def log_message(self,*args):pass

if __name__=='__main__':
    create_db()
    host='127.0.0.1';port=8765
    print('SQL 탐정단 서버가 실행되었습니다. 브라우저에서 http://127.0.0.1:8765 를 열어주세요.')
    print('종료하려면 이 창에서 Ctrl+C를 누르세요.')
    ThreadingHTTPServer((host,port),Handler).serve_forever()
